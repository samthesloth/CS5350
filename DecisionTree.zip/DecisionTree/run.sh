#!/bin/sh
py main.py car/train.csv 1
py main.py car/train.csv 2
py main.py car/train.csv 3
py main.py car/train.csv 4
py main.py car/train.csv 5
py main.py car/train.csv 6

py mainmajority.py car/train.csv 1
py mainmajority.py car/train.csv 2
py mainmajority.py car/train.csv 3
py mainmajority.py car/train.csv 4
py mainmajority.py car/train.csv 5
py mainmajority.py car/train.csv 6

py maingini.py car/train.csv 1
py maingini.py car/train.csv 2
py maingini.py car/train.csv 3
py maingini.py car/train.csv 4
py maingini.py car/train.csv 5
py maingini.py car/train.csv 6